export async function onRequestPost({ request, env }) {
  try {
    if (!env.DB) return Response.json({ error: "License database is not configured." }, { status: 500 });
    const { key, deviceId } = await request.json();
    if (typeof key !== "string" || !key.trim() || typeof deviceId !== "string" || deviceId.length < 8) {
      return Response.json({ error: "Invalid key or device." }, { status: 400 });
    }
    const keyHash = await hashKey(key);
    let row = await env.DB.prepare("SELECT key_hash, device_id, expires_at FROM licenses WHERE key_hash = ?").bind(keyHash).first();
    if (!row) return Response.json({ error: "Invalid access key." }, { status: 401 });

    if (!row.device_id && !row.expires_at) {
      await env.DB.prepare(`
        UPDATE licenses
        SET device_id = ?, activated_at = datetime('now'), expires_at = datetime('now', '+30 days')
        WHERE key_hash = ? AND device_id IS NULL AND expires_at IS NULL
      `).bind(deviceId, keyHash).run();
      row = await env.DB.prepare("SELECT device_id, expires_at FROM licenses WHERE key_hash = ?").bind(keyHash).first();
    }

    if (row.device_id !== deviceId) {
      return Response.json({ error: "This key is already linked to another device." }, { status: 403 });
    }
    if (!row.expires_at || Date.parse(row.expires_at.replace(" ", "T") + "Z") <= Date.now()) {
      return Response.json({ error: "This key has expired. Please get a new key." }, { status: 403 });
    }
    return Response.json({ ok: true, expiresAt: row.expires_at });
  } catch {
    return Response.json({ error: "Server error while activating the key." }, { status: 500 });
  }
}
async function hashKey(key) {
  const bytes = new TextEncoder().encode(key.trim());
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, "0")).join("");
}
