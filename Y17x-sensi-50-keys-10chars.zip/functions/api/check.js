export async function onRequestPost({ request, env }) {
  try {
    if (!env.DB) return Response.json({ error: "License database is not configured." }, { status: 500 });
    const { key, deviceId } = await request.json();
    if (typeof key !== "string" || !key.trim() || typeof deviceId !== "string") {
      return Response.json({ valid: false }, { status: 400 });
    }
    const bytes = new TextEncoder().encode(key.trim());
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    const hash = [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, "0")).join("");
    const row = await env.DB.prepare("SELECT device_id, expires_at FROM licenses WHERE key_hash = ?").bind(hash).first();
    if (!row || row.device_id !== deviceId || !row.expires_at ||
        Date.parse(row.expires_at.replace(" ", "T") + "Z") <= Date.now()) {
      return Response.json({ valid: false }, { status: 403 });
    }
    return Response.json({ valid: true, expiresAt: row.expires_at });
  } catch {
    return Response.json({ valid: false }, { status: 500 });
  }
}
