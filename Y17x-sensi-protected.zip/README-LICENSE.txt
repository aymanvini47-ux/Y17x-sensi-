# Y17x DE SENSI — license protection

This project adds a 30-day, first-device activation gate using Cloudflare Pages Functions + D1.

## Cloudflare setup

1. Create a **D1 database** in Cloudflare.
2. In the D1 console, run `migrations/0001_create_licenses.sql`.
3. In your Pages project, open **Settings → Functions → D1 database bindings**.
   Add a binding named `DB` and select the database.
4. In **Settings → Environment variables**, add `ADMIN_SECRET` with a long random secret. Set it for Production (and Preview only if needed).
5. Deploy this folder as the Cloudflare Pages project (the `index.html`, `bg.mp4`, `functions/`, and `migrations/` files must be in the deployed project).

## Create access keys

After deployment, send a POST request to `/api/admin-create` with header:

`Authorization: Bearer YOUR_ADMIN_SECRET`

and JSON body:

`{"count": 5}`

The response contains the new keys. Each key can be activated by only one browser/device identity and starts its 30-day expiry at first activation. Store the keys safely; they are shown only once.

## Important device limitation

A normal website cannot read an iPhone/PC hardware serial number. This implementation creates a random browser device ID and stores it in local storage. The server binds the key to that ID. Clearing website data, using a different browser, or switching devices may make the original browser ID unavailable; the key will remain bound and you will need an administrator to issue a replacement/reset.

## Security limitation

This is a real server-checked license gate, not just a password written in HTML. However, the current calculator/checklist page is still a static website: its source files and client-side logic can be inspected by a technically skilled visitor. For content that must be impossible to access without a license, move the protected data/features behind authenticated server endpoints or use Cloudflare Access for the whole site.
