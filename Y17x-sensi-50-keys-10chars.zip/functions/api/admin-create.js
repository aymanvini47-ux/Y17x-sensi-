export async function onRequestPost({ request, env }) {
  try {
    if (!env.DB || !env.ADMIN_SECRET) {
      return Response.json({ error: "Admin settings are not configured." }, { status: 500 });
    }
    if (request.headers.get("Authorization") !== `Bearer ${env.ADMIN_SECRET}`) {
      return Response.json({ error: "Unauthorized." }, { status: 401 });
    }
    const body = await request.json().catch(() => ({}));
    const count = Math.max(1, Math.min(20, Number(body.count) || 1));
    const keys = [];
    for (let i = 0; i < count; i++) {
      const random = crypto.getRandomValues(new Uint8Array(18));
      const key = "Y17X-" + [...random].map(b => b.toString(16).padStart(2, "0")).join("").toUpperCase();
      const bytes = new TextEncoder().encode(key);
      const digest = await crypto.subtle.digest("SHA-256", bytes);
      const hash = [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, "0")).join("");
      await env.DB.prepare("INSERT INTO licenses (key_hash, created_at) VALUES (?, datetime('now'))").bind(hash).run();
      keys.push(key);
    }
    return Response.json({ keys, note: "Save these keys now. They are shown only once. Each starts its 30-day period on first activation." });
  } catch {
    return Response.json({ error: "Could not create license keys." }, { status: 500 });
  }
}
