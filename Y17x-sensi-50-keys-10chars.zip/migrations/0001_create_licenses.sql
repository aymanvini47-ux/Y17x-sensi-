CREATE TABLE IF NOT EXISTS licenses (
  key_hash TEXT PRIMARY KEY,
  device_id TEXT,
  created_at TEXT NOT NULL,
  activated_at TEXT,
  expires_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_licenses_device_id ON licenses(device_id);
